"""Administration plateforme."""
